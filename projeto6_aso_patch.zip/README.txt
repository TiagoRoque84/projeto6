Projeto: Patch de ASO (filtro + cards) para projeto6 (Flask + sqlite3)

Como usar (2 jeitos):

JEITO RÁPIDO (recomendado):
1) Extraia este ZIP dentro da pasta do projeto (mesmo nível do app.py).
2) Dê dois cliques em: apply_aso_patch.bat
   - Ele cria backup automático em _backup_aso_patch_YYYYMMDD_HHMMSS
   - Aplica as mudanças em app.py, blueprints/rh/routes.py,
     templates/rh/funcionarios_list.html e templates/index.html

JEITO VIA TERMINAL:
1) Extraia este ZIP dentro da pasta do projeto.
2) Rode:
   python scripts\apply_aso_patch.py "%CD%"

Depois:
- Reinicie o servidor (python app.py) e teste:
  * /rh/funcionarios  (botão "Filtrar" + campo "Dias")
  * /                 (cards com nomes: vencidos e a vencer em 30 dias)

Observações:
- Datas no banco devem estar como YYYY-MM-DD.
- O script faz mudanças não destrutivas e tenta preservar seu código.
- Se algo sair do esperado, restaure os arquivos do backup gerado.
