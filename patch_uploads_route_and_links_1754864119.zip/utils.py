
import os
import uuid
from werkzeug.utils import secure_filename
from flask import current_app

ALLOWED_EXTENSIONS = {'.pdf', '.png', '.jpg', '.jpeg'}

def _allowed(name):
    ext = os.path.splitext(name)[1].lower()
    return ext in ALLOWED_EXTENSIONS or ext == ''

def save_file(storage, subdir):
    """Save an uploaded file under <app.root>/uploads/<subdir>/
    Returns the *relative* path starting at the uploads root (e.g. 'func_docs/abc.pdf').
    """
    if not storage or storage.filename == '':
        return None
    filename = secure_filename(storage.filename)
    # add short random prefix to avoid collisions
    prefix = uuid.uuid4().hex[:8]
    name, ext = os.path.splitext(filename)
    if not _allowed(filename):
        # still save, but keep original ext to not break; policy can be hardened later
        pass
    filename = f"{prefix}_{name}{ext}"
    abs_root = os.path.join(current_app.root_path, 'uploads', subdir)
    os.makedirs(abs_root, exist_ok=True)
    abs_path = os.path.join(abs_root, filename)
    storage.save(abs_path)
    # return RELATIVE to /uploads route
    return f"{subdir}/{filename}".replace('\\','/')
