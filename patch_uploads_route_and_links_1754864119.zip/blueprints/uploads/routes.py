
import os
from flask import Blueprint, current_app, send_from_directory
from flask_login import login_required

uploads_bp = Blueprint("uploads", __name__)

@uploads_bp.route("/uploads/<path:filename>")
@login_required
def serve_upload(filename):
    # Serve from <app.root>/uploads
    root = os.path.join(current_app.root_path, "uploads")
    return send_from_directory(root, filename, as_attachment=False)
