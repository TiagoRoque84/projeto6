PATCH ASO v2.1
--------------
1) Extraia este ZIP dentro da pasta do projeto (mesmo nível do app.py).
2) Clique duas vezes em apply_aso_patch_v2_1.bat
   - Cria backup em _backup_aso_patch_v2_1_YYYYMMDD_HHMMSS
   - Atualiza app.py e blueprints/rh/routes.py
   - Atualiza o template de lista (colaboradores_list.html OU funcionarios_list.html)
   - Injeta os cards de nomes na index.html
3) Rode: python app.py

Testes:
- /rh/colaboradores OU /rh/funcionarios  (filtro de ASO + Dias)
- /  (cards de ASO com nomes)

Datas no banco em YYYY-MM-DD. Restauração: copie os arquivos do backup de volta.
