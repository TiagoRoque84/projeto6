
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
import os
from datetime import date

styles = getSampleStyleSheet()
H1 = ParagraphStyle('H1', parent=styles['Heading1'], fontSize=16, spaceAfter=8)
N = styles['Normal']

def _s(v): return "" if v is None else str(v)
def P(v):  # wrap text in Paragraph to allow word-wrapping
    return Paragraph(_s(v), N)

def employee_pdf(buffer, app, e):
    # Page width = 21cm / margins 2cm => 17cm usable
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=1.5*cm, bottomMargin=1.5*cm)
    elems=[]

    # Header: title + photo side by side to avoid overlap with details table
    title = Paragraph(f"Ficha do Colaborador - #{e.id}", H1)
    photo_flow = None
    if e.foto_path:
        try:
            photo_abs = os.path.join(app.root_path, e.foto_path)
            photo_flow = Image(photo_abs, width=4*cm, height=4.8*cm)
        except Exception:
            photo_flow = None
    header = Table([[title, photo_flow]], colWidths=[12.5*cm, 4.5*cm])  # 17cm total
    header.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP')]))
    elems.append(header)
    elems.append(Spacer(1,0.3*cm))

    # Details table — use Paragraphs for wrapping and fix widths to 17cm total
    data=[
        ["Nome", P(e.nome), "Empresa", P(e.company.razao_social if e.company else "")],
        ["Função", P(e.funcao.nome if e.funcao else ""), "Ativo", P("Sim" if e.ativo else "Não")],
        ["CPF", P(e.cpf), "RG", P(e.rg)],
        ["Nascimento", P(e.data_nascimento), "Gênero", P(e.genero)],
        ["Estado civil", P(e.estado_civil), "Admissão", P(e.data_admissao)],
        ["Salário (R$)", P(e.salario), "Jornada", P(e.jornada)],
        ["Telefone", P(e.fone), "Celular", P(e.celular)],
        ["E-mail", P(e.email), "", ""],
        ["Endereço", P(f"{_s(e.logradouro)}, {_s(e.numero)} {_s(e.complemento)}"), "CEP", P(e.cep)],
        ["Bairro/Cidade/UF", P(f"{_s(e.bairro)} / {_s(e.cidade)} / {_s(e.uf)}"), "", ""],
        ["Banco", P(e.banco), "Agência/Conta", P(f"{_s(e.agencia)} / {_s(e.conta)}")],
        ["Tipo de conta", P(e.tipo_conta), "PIX", P(f"{_s(e.pix_tipo)}: {_s(e.pix_chave)}")],
        ["ASO", P(e.aso_tipo), "Validade", P(e.aso_validade)],
        ["CNH", P(e.cnh), "CNH Validade", P(e.cnh_validade)],
        ["Toxicológico", "", "Validade", P(e.exame_toxico_validade)],
    ]
    # 17 cm usable width: 3.0 + 8.0 + 3.0 + 3.0 = 17.0
    table = Table(data, colWidths=[3.0*cm,8.0*cm,3.0*cm,3.0*cm])
    table.setStyle(TableStyle([
        ('GRID',(0,0),(-1,-1),0.25,colors.grey),
        ('FONTSIZE',(0,0),(-1,-1),9),
        ('VALIGN',(0,0),(-1,-1),'TOP'),
    ]))
    elems.append(table)
    elems.append(Spacer(1,0.5*cm))
    elems.append(Paragraph(f"Gerado em {date.today().strftime('%d/%m/%Y')}", N))
    doc.build(elems)
